prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 89023
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.14'
,p_default_workspace_id=>20575405984736225816
,p_default_application_id=>89023
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARCHI04'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(156634764167104000270)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
